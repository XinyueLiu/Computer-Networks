/*
 * To compile it:
 *    g++ -ggdb -Wall hello.cpp
 *
 * To run it:
 *    a.out
 */


// needed to do IO
#include <iostream>
#include <limits>
#include <vector>
#include <string>
#include <sstream>
#include <fstream>

using namespace std;

void  BellmanFord(int size, const char* filename){
	std::ifstream infile(filename);
  	std::string line;
  	int row = 0;
  	int map[size][size];
	std::vector<int> tmpV;
	std::vector<int> routeV;
	string route = "";
	int i,j,tmp,m ;
	int imax =std::numeric_limits<int>::max();
	int preNode[size];
	int dPrev[size];
	int d[size];
	d[0] = 0;
	for(i = 1; i<size; i++){
		d[i] = imax;
	}
	int iteration = 0;
	routeV.push_back(0);
	preNode[0] = 0;

	while (std::getline(infile, line))
	{
		int j = 0;
		int curr = 0;
		bool flag = false;
		bool positive = true;
		//cout<<line<<'\n';
		int tmp;
		for(std::string::iterator it = line.begin(); it != line.end(); ++it) {
			//cout<< *it << ' ';
			if(*it == '*'){
				curr = 0;
				flag = false;
				positive = true;
				map[row][j] = imax;
				//cout << map[row][j] << " ";
				j++;
			}
			
			if(*it != ',' && *it != '*'){
				//cout << "Suppose to be a number:" << *it << '\n';
				if(*it == '-'){
					positive = false;
				}
				if((int) *it >=48 && (int) *it <=57){
					flag = true;
					tmp = *it - '0';
					//cout << "tmp:" << tmp << '\n';
					curr = curr*10 + tmp;
				}
				
			}
			if(flag==true && *it == ','){
				if(positive == false){
					map[row][j] = -curr;
				}else{
					map[row][j] = curr;
				}
				
				curr = 0;
				//cout << map[row][j] << " ";
				j++;
				flag = false;
				positive = true;
			}
			if(j == size || *it == ' '){
				break;
			}
		}
		//cout<< '\n';
		if(flag == true && j==size-1){
			map[row][j] = curr;
		}
		row++;
    	//cout<< '\n';
	}

	//DEBUG: print map
	// for(i=0; i<size; i++){
	// 	for(j=0; j<size; j++){
	// 		cout<<map[i][j] << " ";
	// 	}
	// 	cout<<'\n';
	// }


	for(i=1; i<size; i++){
		iteration++;
		for(j=0; j<size; j++){
			dPrev[j] = d[j];
		}
		if(i > 1){
			for (std::vector<int>::iterator it = routeV.begin() ; it != routeV.end(); ++it){
				for(m=0; m<size; m++){
					if(map[*it][m] != imax && map[*it][m] != 0){
						tmpV.push_back(m);
					}
				}

			}
			routeV = tmpV;
			tmpV.erase (tmpV.begin(),tmpV.end());
		}

		//DEBUG: print curr d[]
		// cout << "i:" << i << '\n';
		// for(m=0; m<size; m++){
		// 	cout<< d[m] << " ";
		// }
		// std::cout << '\n';


		//DEBUG: print curr route
		// cout<< "route:" << '\n';
		// cout << "i:" << i << '\n';
		// for (std::vector<int>::iterator it = routeV.begin() ; it != routeV.end(); ++it){
		// 	cout << *it << ' ';
		// }
		// std::cout << '\n';

		for(m=0; m<size; m++){
			for (std::vector<int>::iterator it = routeV.begin() ; it != routeV.end(); ++it){
				if(map[*it][m] !=imax && d[m] > (d[*it]+map[*it][m])){
					d[m] = d[*it]+map[*it][m];
					preNode[m] = *it;
				}
			}
			
		}

		//check iteration 
		for(j=0; j<size; j++){
			if(dPrev[j] != d[j]){
				break;
			}
		}

		if(j == size) {
			for(tmp=0; tmp<size-1; tmp++){
				cout<< d[tmp] << ',';
			}
			cout<< d[tmp];
			cout<< '\n';

			for(tmp=0; tmp<size; tmp++){
				m = preNode[tmp];
				std::string s;
				std::stringstream out;
				out.str("");
				out << tmp;
				route = out.str();
				while(m != 0){
					out.str("");
					out << m;
					route = out.str() + "->" + route;
					m = preNode[m];
				}
				if(tmp != 0){
					out.str("");
					out << 0;
					route = out.str() + "->" + route;
				}
				cout<<route<<'\n';

			}
			cout<<"Iteration:" << iteration << '\n';
			break; 
		}
	}

	//check negative loop - plus node
	if(i==size){
		for (std::vector<int>::iterator it = routeV.begin() ; it != routeV.end(); ++it){
				for(m=0; m<size; m++){
					if(map[*it][m] != imax && map[*it][m] != 0){
						tmpV.push_back(m);
					}
				}

		}
		routeV = tmpV;

		for(m=0; m<size; m++){
			for (std::vector<int>::iterator it = routeV.begin() ; it != routeV.end(); ++it){
				if(map[*it][m] !=imax && d[m] > (d[*it]+map[*it][m])){
					d[m] = d[*it]+map[*it][m];
					preNode[m] = *it;
				}
			}
			
		}

		for(m=0; m<size; m++){
			if(dPrev[m] > d[m]){
				cout<<"Negative Loop Detected" << '\n';
				tmp = preNode[m];
				std::string s;
				std::stringstream out;
				out.str("");
				out << m;
				route = out.str();
				while(tmp != m){
					out.str("");
					out << tmp;
					route = out.str() + "->" + route;
					tmp = preNode[tmp];
				}
				
				out.str("");
				out << m;
				route = out.str() + "->" + route;
				cout<<route<<'\n';
				break;
			}
		}
	}



}

int main(int argc, char * argv[]) {
  int size = 1;
  if(argc > 1){
  	std::ifstream infile(argv[1]);
  	std::string line;
  	if(std::getline(infile, line)){
  		const char *p = line.c_str();
		p = strchr(p, ',');
		while( p != NULL ) {
			size++;
			p++;
    		p = strchr(p, ',');
    			
		}
  	}
  	BellmanFord(size,argv[1]);
  }
  return 0;
}
